import { Routes } from '@angular/router';

import { TodolistComponent } from './todolist.component';
// import { DocPopComponent } from '../docpop/docpop.component';

export const TodolistRoutes: Routes = [
  // { path: '', component: DocPopComponent },
  { path: '', component: TodolistComponent }
];



