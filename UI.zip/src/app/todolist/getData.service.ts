/*import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers, Request } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

@Injectable()
export class GetDataService {
    public http: Http;
    public requestConfig: any;
    public request: any;
    public requestoptions: any;
    public getHeaders() {
        let headers = new Headers();
        headers.append('Content-type', 'application/json');
        headers.append('Access-Control-Allow-Origin', '*');
        headers.append('Access-Control-Allow-Methods', 'GET, POST, PATCH, PUT, DELETE, OPTIONS');
        headers.append('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, X-Auth-Token');
        return headers;
    }
    get(url: string, params?: any): any {
        this.get(url).map((res: Response) => { return res; });
    }

    post(url: string, data?: any) {
        this.requestConfig = this.getRequestConfig('POST', url, null, data, this.getHeaders());
        return this.fireHttpRequest(this.requestConfig);
    }

    getRequestConfig(getMethod: string, getUrl: string, params: any, data: any, getHeaders: any) {
        this.request = {
            url: getUrl,
            method: getMethod
        };
        if (getHeaders) {
            this.request.headers = getHeaders;
        }
        if (params) {
            this.request.params = params;
        }
        if (data) {
            this.request.body = data;
        }
        return this.request;
    }

    fireHttpRequest(requestConfigData: any) {
        this.requestoptions = new RequestOptions(requestConfigData);
        return this.http.request(new Request(this.requestoptions))
            .map((res: Response) => {
                if (res) {
                    return [{ status: res.status, headers: res.headers, json: res.json() }];
                }
            });
    }
    handleError(error: Response) {
        console.error('MeetingService error: HTTP status ' + error.status);    // status is 200
        return Observable.throw(error.json() || 'Server error: MeetingService');
    }
}
*/
import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Rx';
// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class GetDataService {
    private FileMetadataUrl = 'category.json';
    // Resolve HTTP using the constructor
    constructor(private http: Http) { }
    // private instance variable to hold base url   
    // Fetch all existing comments
    get() {
        // let filemetadataString = JSON.stringify(filemetadata); // Stringify payload
        let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
        let options = new RequestOptions({ headers: headers }); // Create a request option

        return this.http.get(this.FileMetadataUrl, options) // ...using post request
            .map((res: Response) => console.log(res.json())) // ...and calling .json() on the response to return data
            .catch((error: any) => Observable.throw(error.json().error || 'Server error')); // ...errors if any
    }
}
