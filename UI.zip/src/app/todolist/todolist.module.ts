import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CompletedFilterPipe, TodolistComponent /*,DocPopComponent*/} from './index';
import { GetDataService } from './getData.service';
// import {CalendarModule} from 'primeng/primeng';


@NgModule({
    declarations: [
        CompletedFilterPipe,
        TodolistComponent
        /*DocPopComponent*/


    ],
    imports: [
        FormsModule,
        CommonModule
    ],
    exports: [
        CompletedFilterPipe,
        TodolistComponent
        /*DocPopComponent*/

    ],
    providers: [GetDataService]
})
export class TodolistModule {
}

