/*import { Component } from '@angular/core';
import './docpop.component.html';
@Component({
    moduleId: module.id,
    selector: 'as-docpop',
    template: require('./docpop.component.html')
})
export class DocPopComponent {
    constructor() {

    }

}*/
