module.exports = [
    'node_modules/systemjs/dist/system-polyfills.js',
    'node_modules/systemjs/dist/system.src.js',
    'node_modules/zone.js/dist/**/*.+(js|js.map)',
    'node_modules/es6-shim/es6-shim.js',
    'node_modules/reflect-metadata/**/*.+(ts|js|js.map)',
    'node_modules/rxjs/**/*.+(js|js.map)',
    'node_modules/@angular/**/*.+(js|js.map)',
    'node_modules/core-js/**/*.+(js|js.map)',
    'node_modules/jquery/**/*.+(js|js.map)',
    'node_modules/bootstrap-sass/**/*.+(js|css|png|eot|svg|ttf|woff|jpg|gif)',
    'node_modules/font-awesome/**/*.+(css|png|eot|svg|ttf|woff|woff2|jpg|gif)',
    'node_modules/lodash/**/*.+(js|js.map)',
    'node_modules/systemjs-plugin-text/**/*.+(js|js.map)',
    'node_modules/systemjs-plugin-css/**/*.+(js|js.map)',
    'node_modules/microui-contracts/**/*.+(js|js.map)'
];